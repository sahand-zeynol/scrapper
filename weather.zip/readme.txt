!!! IMPORTANT !!!
1.change index.txt file extension to js
2.run npm i
3.run npm run start 